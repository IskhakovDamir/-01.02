﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Damir_BMIcalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double h = Convert.ToDouble(textBox1.Text)/100;
            double m = Convert.ToDouble(textBox2.Text);
            int bmi = Convert.ToInt32( m / (h * h));
            label16.Text = bmi.ToString();

            if (bmi < 10) { trackBar1.Value = 10; label15.Text = "недостаточный"; }

            if (bmi <= 18.5 && bmi >= 10) { trackBar1.Value = Convert.ToInt32(bmi); label15.Text = "Недостаточный"; }

            if (bmi > 18.5 && bmi <= 24.9) { trackBar1.Value = Convert.ToInt32(bmi); label15.Text = "Здоровый"; }

            if (bmi > 24.9 && bmi <= 29.9) { trackBar1.Value = Convert.ToInt32(bmi); label15.Text = "Избыточный"; }

            if (bmi > 30 && bmi < 35){ trackBar1.Value = Convert.ToInt32(bmi); label15.Text = "Ожирение"; }

            if (bmi > 35) { trackBar1.Value = 35; label15.Text = "Ожирение"; }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
